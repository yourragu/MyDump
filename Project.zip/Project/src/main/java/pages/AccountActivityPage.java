package pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.LeafTapsWrappers;

public class AccountActivityPage extends LeafTapsWrappers  {

	// This is to confirm you are in Login Page
	public AccountActivityPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;

		if(!verifyTitle("Oregon ABLE Savings Plan - Account Activity")){
			reportStep("This is not Account Activity Page", "FAIL");
		}
	}

	//Click Account tile in the dashboard
	public AccountActivityPage ClickAccountActivity() throws InterruptedException{
		clickByLink("Edit account information");
		Thread.sleep(3000);
		return new AccountActivityPage(driver,test);

	}
	

	}
