package pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.LeafTapsWrappers;

public class AccountOverViewPage extends LeafTapsWrappers  {

	// This is to confirm you are in Login Page
	public AccountOverViewPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;

		if(!verifyTitle("Oregon ABLE Savings Plan - Account Overview")){
			reportStep("This is not Account OverView Page", "FAIL");
		}
	}

	//Click Account tile in the dashboard
	public EditAccountInformationPage ClickEditAccountInformationLink() throws InterruptedException{
		clickByLink("Edit account information");
		Thread.sleep(3000);
		return new EditAccountInformationPage(driver,test);

	}
	
	
	//Click Transfers Link
			public InstantTransfersPage ClickTransfersLink() throws InterruptedException{
				clickByXpath("//span[text()[contains(.,'Transfers')]]");
				Thread.sleep(3000);
				return new InstantTransfersPage(driver,test);

			}
	

	}
