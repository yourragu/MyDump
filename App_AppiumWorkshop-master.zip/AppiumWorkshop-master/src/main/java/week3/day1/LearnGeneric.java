package week3.day1;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import io.appium.java_client.android.AndroidDriver;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;

public class LearnGeneric {

	/**
	 * @param args
	 * @throws MalformedURLException 
	 */
	public static void main(String[] args) throws MalformedURLException {
		// TODO Auto-generated method stub
		
		
		 
		ArrayList<String> list = new ArrayList<String>();
		list.add("Raj");
//		list.add(5);
		

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
