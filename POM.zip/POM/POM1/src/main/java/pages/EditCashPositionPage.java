package pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.LeafTapsWrappers;

public class EditCashPositionPage extends LeafTapsWrappers  {

	// This is to confirm you are in Login Page
	public EditCashPositionPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;

		if(!verifyTitle("Oregon ABLE Savings Plan - Cash Position")){
			reportStep("This is not Cash Position Page", "FAIL");
		}
	}

	//Enter Investment Allocation Percentage
	public EditCashPositionPage EnterAllocation(String Investment) throws InterruptedException{
		enterById("investmentContributionPercentage", Investment);
		Thread.sleep(2000);
		return new EditCashPositionPage(driver, test);

	}
	
	//Enter Cash Allocation Percentage
		public EditCashPositionPage EnterCashAllocation(String CashInvestment) throws InterruptedException{
			enterById("cashContributionPercentage", CashInvestment);
			Thread.sleep(2000);
			return new EditCashPositionPage(driver, test);

		}
	

	//Click distribution Save changes button
	public EditCashPositionPage Clickcustomizesavechanges() throws InterruptedException{
		clickByXpath("//button[text()[contains(.,'Save Changes')]]");
		Thread.sleep(10000);
		return this;

	}
	//Click distribution confirmation
	public EditCashPositionPage VerifydistributionConfirmation() throws InterruptedException{
		verifyTextById("takeoverTitle", "We made your changes");
		verifyTextByXpath("//p[@id='takeoverDescription']", "Your target allocation has been updated.");
		Thread.sleep(2000);
		return this;

	}

	//Click Continue distribution confirmation screen
	public EditAccountInformationPage ClickContinue() throws InterruptedException{
		clickByXpath("//button[text()[contains(.,'Continue')]]");
		Thread.sleep(2000);
		return new EditAccountInformationPage(driver,test);

	}
	
	//Click Next
		public InvestmentSelectionPage ClickNext() throws InterruptedException{
			clickByXpath("//button[text()[contains(.,'Continue')]]");
			Thread.sleep(2000);
			return new InvestmentSelectionPage(driver,test);

		}


}
