package testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import pages.LoginPage;
import wrappers.LeafTapsWrappers;

public class TC018_LoggedOut_HelpScreen extends LeafTapsWrappers{

	@BeforeClass
	public void setData() {
		testCaseName="Verify Logged Out version of Help Screen";
		testDescription="Help Screen Logged Out Version";
		browserName="chrome";
		dataSheetName="TC018_Help_LoggedOut";
		category="Sumday Able Program";
		authors="Ragunath";
	}

	@Test(dataProvider="fetchData")
	public void HelpLoggedOut(String name,String PhNo, String Message, String text2, String text3) throws InterruptedException{

		new LoginPage(driver, test)
		.ClickGetHelp()
		.SavingsFAQ()
		.ClickSavingsContactUs()
		.EnterName(name)
		.ChooseOption()
		.EnterPhoneNum(PhNo).EnterMessage(Message)
		.ClickSend()
		.VerifyConfTitle(text2)
		.VerifyconfDescription(text3)
		.ClickContinue()
		
		;
		
		
	}

}
