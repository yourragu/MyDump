package testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import pages.LoginPage;
import wrappers.LeafTapsWrappers;

public class TC017_LoggedIn_HelpScreen extends LeafTapsWrappers{

	@BeforeClass
	public void setData() {
		testCaseName="Verify Logged In version of Help Screen";
		testDescription="Help Screen Logged In Version";
		browserName="chrome";
		dataSheetName="TC017_Help_LoggedIn";
		category="Sumday Able Program";
		authors="Ragunath";
	}

	@Test(dataProvider="fetchData")
	public void HelpLoggedIn(String Email, String Password, String Message, String text1, String text2) throws InterruptedException{

		new LoginPage(driver, test)
		.EnterEmailID(Email)
		.EnterPassWord(Password)
		.ClickLogin()
		.ClickLoggedInHelp()
		.SavingsFAQ()
		.ClickSavingsContactUs()
		.ClickPhOption()
		.ClickAccount()
		.SelectAccount()
		.EnterMessage(Message)
		.ClickSend()
		.VerifyConfTitle(text1)
		.VerifyconfDescription(text2)
		.ClickContinue()
		
		;
		
		
	}

}
