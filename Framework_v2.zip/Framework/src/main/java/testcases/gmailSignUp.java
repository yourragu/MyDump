package testcases;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import containers.Basecontainer;
import pages.GMailSignUpPage;
import pages.Googlepage;

public class gmailSignUp extends Basecontainer {

	@BeforeMethod
	public void startDriver() {
		launchBrowser("chrome");
		launchAppication("https://accounts.google.com/signup?hl=en-GB");
	}

	@Test(dataProvider = "source")
	public void test1(String toRun, String text) throws IOException, InterruptedException {

		new GMailSignUpPage(driver).clickNext("//span[text()='Next']").verifyFName("//div[text()='Enter first name']",
				"Enter first name");

		if (flag) {
			enterByXpath("//*[@name='firstName']", "Besant");
			flag = false;
		}

		new GMailSignUpPage(driver).verifyLName("//div[text()='Enter last name']", "Enter last name");
		if (flag) {
			enterByXpath("//*[@name='lastName']", "Texhnologies");
			flag = false;
		}
		
		new GMailSignUpPage(driver)

				.enterEmailId("//input[@id='username']", "viswanath")
				.verifyPwd("//*[text()='Enter a password']", "Enter a password");
		if (flag) {
			enterByXpath("//*[@name='Passwd']", "123456789");
		}

		new GMailSignUpPage(driver)
		.verifyConfPwd("//*[@name='ConfirmPasswd']", "123456789");
	}

	@DataProvider(name = "source")
	public Object[][] getData() {
		return supporting_utilities.DataInputProvider.ReadExcel("C://Users//Yourragu//Desktop//ReadingExcelSheet.xls");
	}

}