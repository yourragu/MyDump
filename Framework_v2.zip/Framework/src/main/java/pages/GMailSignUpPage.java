package pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.remote.RemoteWebDriver;

import containers.Basecontainer;

public class GMailSignUpPage extends Basecontainer {

	public GMailSignUpPage(RemoteWebDriver driver) {
		this.driver = driver;
	}

	public GMailSignUpPage clickNext(String xpath) {

		clickByXpath(xpath);
		return this;
	}

	public GMailSignUpPage enterFName(String fname, String xpath) {

		enterByName(fname, xpath);
		return this;
	}

	public GMailSignUpPage enterLName(String lname, String xpath) {

		enterByName(lname, xpath);
		return this;
	}

	public GMailSignUpPage verifyFName(String xpath, String expected) {

		verifyText(xpath, expected);
		return this;
	}

	public GMailSignUpPage verifyLName(String xpath, String expected) {

		verifyText(xpath, expected);
		return this;
	}
	
	public GMailSignUpPage enterEmailId(String xpath, String mailId) {

		enterByXpath(xpath, mailId);
		return this;
	}
	
	public GMailSignUpPage verifyPwd(String xpath, String mailId) {

		verifyText(xpath, mailId);
		return this;
	}

	
	public GMailSignUpPage verifyConfPwd(String xpath, String mailId) {

		verifyText(xpath, mailId);
		return this;
	}



}
