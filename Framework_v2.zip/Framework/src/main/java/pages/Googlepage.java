package pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.remote.RemoteWebDriver;

import containers.Basecontainer;

public class Googlepage extends Basecontainer {

	public Googlepage(RemoteWebDriver driver) {
		this.driver = driver;
	}

	public Googlepage enterTextInTextBox(String text) throws InterruptedException {
		enterByName("q", text);
		return this;
	}

	public Searchpage clickSearchBtn(String button) throws InterruptedException {
		Thread.sleep(2000);
		clickByXpath(button);
		return new Searchpage(driver);
	}

}
