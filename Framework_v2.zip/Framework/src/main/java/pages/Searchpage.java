package pages;

import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.PageFactory;

import containers.Basecontainer;

public class Searchpage extends Basecontainer{
	
	public Searchpage(RemoteWebDriver driver)
	{
		this.driver = driver;
	}
	
	

	public Resultpage clickLink()
	{
		clickByXpath("//*[text()='Selenium - Web Browser Automation']");
		return new Resultpage(driver);
		
	}

}
