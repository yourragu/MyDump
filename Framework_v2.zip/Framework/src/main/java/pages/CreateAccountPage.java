package pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.remote.RemoteWebDriver;

import containers.Basecontainer;

public class CreateAccountPage extends Basecontainer {

	public CreateAccountPage(RemoteWebDriver driver) {
		this.driver = driver;
	}

	

}
