package containers;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

public class Test1  {
	Basecontainer bc = new Basecontainer();
	@Test
	public void a() {

		bc.launchBrowser("chrome");
		bc.launchAppication("http://demo.automationtesting.in/Register.html");
		
		bc.enterByXpath("(//*[@type='text'])[1]", "Besant");
		bc.enterByXpath("(//*[@type='text'])[2]", "Technologies");
		WebElement x = bc.driver.findElement(By.xpath(""));
		
		
	
		
		
	}

}
