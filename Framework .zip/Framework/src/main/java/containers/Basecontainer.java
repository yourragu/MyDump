package containers;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;

public class Basecontainer {
	public RemoteWebDriver driver;
	protected Properties prop;
	public int i = 1;
	String path = System.getProperty("user.dir");
	
	
	public void propertyFile() throws FileNotFoundException, IOException
	{
		prop.load(new FileInputStream("./src/main/resources/config.properties"));
		
	}
	

	public void launchBrowser(String browser) {
		if(browser.equalsIgnoreCase("chrome")){
		System.setProperty("webdriver.chrome.driver",
				"C://Users//Yourragu//Downloads//chromedriver_win32//chromedriver.exe");
		driver = new ChromeDriver();
		
		}
		else
		{
			if(browser.equalsIgnoreCase("ie"))
			{
				System.setProperty("webdriver.ie.driver",
						"D://Workspace//sel//drivers//IEDriverServer.exe");
				driver = new InternetExplorerDriver();	
			}
			else
			{
				System.setProperty("webdriver.gecko.driver",
						"D://Workspace//sel//drivers//geckodriver-V23//geckodriver.exe");
				driver = new FirefoxDriver();	
			}
		}
	}

	public void launchAppication(String url) {
		try {
			driver.navigate().to(url);
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		} catch (Exception e) {

			e.printStackTrace();
		}
	}

	public void clickById(String id) {
		try {
			driver.getKeyboard().sendKeys(Keys.ESCAPE);
			WebElement ele = driver.findElement(By.id(id));
			ele.click();
		} catch (Exception e) {

			e.printStackTrace();
		}
	}

	public void clickByName(String name) {
		try {
			driver.getKeyboard().sendKeys(Keys.ESCAPE);
			driver.findElement(By.name(name)).sendKeys(Keys.ENTER);
		
		} catch (Exception e) {

			e.printStackTrace();
		}
	}

	public void clickByXpath(String xpath) {
		try {
			driver.getKeyboard().sendKeys(Keys.ESCAPE);
			driver.findElement(By.xpath(xpath)).click();
		} catch (Exception e) {

			e.printStackTrace();
		}
	}

	public void enterById(String id, String Text) {
		try {
			WebElement ele = driver.findElement(By.id(id));
			ele.sendKeys(Text);
		} catch (Exception e) {

			e.printStackTrace();
		}

	}

	public void enterByName(String name, String Text) {
		try {
			WebElement ele = driver.findElement(By.name(name));
			ele.sendKeys(Text);
		} catch (Exception e) {

			e.printStackTrace();
		}

	}

	public void enterByXpath(String xpath, String Text) {
		try {
			WebElement ele = driver.findElement(By.xpath(xpath));
			ele.sendKeys(Text);
		} catch (Exception e) {

			e.printStackTrace();
		}

	}

	public void swithToLastWindow() {
		try {
			Set<String> allwindows = driver.getWindowHandles();
			System.out.println("Total number of available windows:" + allwindows);
			for (String window : allwindows) {
				driver.switchTo().window(window);

			}
		} catch (Exception e) {

			e.printStackTrace();
		}
	}

	public void switchToParentWindow() {
		try {
			Set<String> allwindows = driver.getWindowHandles();
			System.out.println("Total number of available windows:" + allwindows);
			for (String window : allwindows) {
				driver.switchTo().window(window);
				break;
			}
		} catch (Exception e) {

			e.printStackTrace();
		}
	}

	public void compositeAction(String xpath1, String xpath2) {

		try {
			WebElement ele1 = driver.findElement(By.xpath(xpath1));
			WebElement ele2 = driver.findElement(By.xpath(xpath2));
			Actions act = new Actions(driver);
			act.moveToElement(ele1).moveToElement(ele2).click().build().perform();
		} catch (Exception e) {

			e.printStackTrace();
		}

	}

	public void acceptAlert() {

		try {
			driver.switchTo().alert().accept();
		} catch (Exception e) {

			e.printStackTrace();
		}
	}

	public void dismissAlert() {
		try {
			driver.switchTo().alert().dismiss();
		} catch (Exception e) {

			e.printStackTrace();
		}
	}

	public void screenshot(String method) throws IOException {

		try {
			File src = driver.getScreenshotAs(OutputType.FILE);
			System.out.println(path);
			File dest = new File(path + "//screenshot//" + method + i + ".jpg");
			FileUtils.copyFile(src, dest);
		} catch (WebDriverException e) {

			e.printStackTrace();
		}

	}

	public int totalElementsInList(String xpath) {
		int x = 0;
		try {
			List<WebElement> totalelements = driver.findElements(By.xpath(xpath));
			return totalelements.size();
		}

		catch (Exception e) {

			e.printStackTrace();
		}
		return x;

	}

	public void selectByIndex(String id, int index) {
		try {
			new Select(driver.findElement(By.id(id))).selectByIndex(index);
		} catch (Exception e) {

			e.printStackTrace();
		}
	}

	public void selectByValue(String id, String value) {
		try {
			new Select(driver.findElement(By.id(id))).selectByValue(value);
		} catch (Exception e) {

			e.printStackTrace();
		}
	}

	public void selectByVisibleText(String id, String vText) {
		try {
			new Select(driver.findElement(By.id(id))).selectByVisibleText(vText);
		} catch (Exception e) {

			e.printStackTrace();
		}

	}

	public void switchToFrameByName(String name) {
		driver.switchTo().frame(name);
	}

	public void switchToFrameById(int id) {
		driver.switchTo().frame(id);
	}

	public void switchToFrameByWebElement(String xpath) {
		WebElement frm = driver.findElement(By.xpath(xpath));
		driver.switchTo().frame(frm);
	}




}
