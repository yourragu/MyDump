package containers;

public interface I1 {
	
	public void launchAppication(String url);
	
	
	public void clickById(String id);
	


}
