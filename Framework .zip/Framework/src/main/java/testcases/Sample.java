package testcases;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import containers.Basecontainer;
import pages.Googlepage;

public class Sample extends Basecontainer {

	@BeforeMethod
	public void startDriver() {
		launchBrowser("firefox");
		launchAppication("https://www.google.com");
	}

	@Test(dataProvider = "source")
	public void test1(String toRun, String text) throws IOException, InterruptedException {

		
			new Googlepage(driver)

					.enterTextInTextBox(text)
					.clickSearchBtn("(//*[@value='Google Search'])[2]")
					.clickLink()
					.clickDownload();

		
	}

	@DataProvider(name = "source")
	public Object[][] getData() {
		return supporting_utilities.DataInputProvider.ReadExcel("C://Users//Yourragu//Desktop//ReadingExcelSheet.xls");
	}

}