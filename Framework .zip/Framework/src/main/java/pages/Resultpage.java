package pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import containers.Basecontainer;

public class Resultpage extends Basecontainer {
	
	public Resultpage(RemoteWebDriver driver)
	{
		
		this.driver = driver;
	}
	
	public Resultpage clickDownload()
	{
		clickByXpath("//*[text()='Download']");
		return this;
	}

}
