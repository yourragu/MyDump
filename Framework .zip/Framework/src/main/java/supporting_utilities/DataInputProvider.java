package supporting_utilities;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class DataInputProvider {

	public static String[][] ReadExcel(String sheetName) {

		String[][] data = null;

		try {
			/*
			 * File f = new File("D://Book.xlsx"); FileInputStream fis = new
			 * FileInputStream(f);
			 */

			FileInputStream fis = new FileInputStream(sheetName);

			HSSFWorkbook workbook = new HSSFWorkbook(fis);
			HSSFSheet sheet = workbook.getSheetAt(0);

			// get the number of rows
			int rowCount = sheet.getLastRowNum();

			// get the number of columns
			int columnCount = sheet.getRow(0).getLastCellNum();
			data = new String[rowCount][columnCount];

			// loop through the rows
			for (int i = 1; i < rowCount + 1; i++) {
				try {
					HSSFRow row = sheet.getRow(i);
					for (int j = 0; j < columnCount; j++) { 
									
						try {
							String value = "";
							try {

								value = row.getCell(j).getStringCellValue();

							} catch (NullPointerException e) {

							}
							data[i - 1][j] = value;
						} catch (Exception e) {
							e.printStackTrace();
						}
					}

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
	
			workbook.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return data;
	}

}
