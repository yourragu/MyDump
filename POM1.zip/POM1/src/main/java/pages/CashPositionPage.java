package pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.LeafTapsWrappers;

public class CashPositionPage extends LeafTapsWrappers  {

	// This is to confirm you are in Login Page
	public CashPositionPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;

		if(!verifyTitle("Oregon ABLE Savings Plan - Cash Position")){
			reportStep("This is not Cash Position Page", "FAIL");
		}
	}

	//Enter Investment Allocation Percentage
	public CashPositionPage EnterAllocation(String Investment) throws InterruptedException{
		enterById("investmentContributionPercentage", Investment);
		Thread.sleep(2000);
		return new CashPositionPage(driver, test);

	}
	
	//Enter Cash Allocation Percentage
		public CashPositionPage EnterCashAllocation(String CashInvestment) throws InterruptedException{
			enterById("cashContributionPercentage", CashInvestment);
			Thread.sleep(2000);
			return new CashPositionPage(driver, test);

		}
	

	//Click Next
		public InvestmentSelectionPage ClickNext() throws InterruptedException{
			clickByXpath("//button[text()[contains(.,'Next')]]");
			Thread.sleep(5000);
			return new InvestmentSelectionPage(driver,test);

		}


}
