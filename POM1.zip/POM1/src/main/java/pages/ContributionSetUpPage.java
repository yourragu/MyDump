package pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.LeafTapsWrappers;

public class ContributionSetUpPage extends LeafTapsWrappers  {

	// This is to confirm you are in Login Page
	public ContributionSetUpPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;

		if(!verifyTitle("Oregon ABLE Savings Plan - Contribution Setup")){
			reportStep("This is not Contribution SetUp Page", "FAIL");
		}
	}

	//Adding Goal
	public ContributionSetUpPage AddGoal() throws InterruptedException{
		clickByXpath("(//*[@class='side-button'])[1]");
		Thread.sleep(2000);
		return this;
	}


	//MnimumAmount
	public ContributionSetUpPage AddMinimumAmount(String data) throws InterruptedException{
		enterById("oneTimeContribution", data);
		Thread.sleep(2000);
		return this;
	}

	//Setting up Monthly Transfers
	public ContributionSetUpPage MonthlyTransferSetUp() throws InterruptedException{
		clickByXpath("(//*[@class='side-button'])[2]");
		Thread.sleep(2000);
		return this;
	}

	//Edit Monthly Transfer
	public ContributionSetUpPage EditMonthlyTransfer() throws InterruptedException{
		clickByXpath("//*[@aria-label='Edit monthly transfer date']");
		Thread.sleep(2000);
		return this;
	}

	//Verify Error Message
	public ContributionSetUpPage VerifyError(String text) throws InterruptedException{
		verifyTextByXpath("(//*[@class='validation'])", text);
		Thread.sleep(2000);
		return this;
	}

	//Re-Enter Contribution
	public ContributionSetUpPage ReEnterContribution(String data) throws InterruptedException{
		enterById("oneTimeContribution", data);
		Thread.sleep(2000);
		return this;
	}

	//SelectDate
	public ContributionSetUpPage SelectDate() throws InterruptedException{
		clickByXpath("(//*[@type='button'])[30]");
		Thread.sleep(2000);
		return this;
	}

	//Click Done
		public ContributionSetUpPage ClickDone() throws InterruptedException{
			clickByXpath("(//*[@type='submit'])[2]");
			Thread.sleep(2000);
			return new ContributionSetUpPage(driver, test);
		}
	//Click Save and Continue
	public ConnectBankAccountPage ClickSaveAndContinue() throws InterruptedException{
		clickByXpath("//button[text()[contains(.,'Save and continue')]]");
		Thread.sleep(2000);
		return new ConnectBankAccountPage(driver, test);
	}


}
