package pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.LeafTapsWrappers;

public class EditBankAccountPage extends LeafTapsWrappers  {

	// This is to confirm you are in Login Page
	public EditBankAccountPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;

		if(!verifyTitle("Edit Bank Account")){
			reportStep("This is not Edit Bank Account Page", "FAIL");
		}
	}

	// Select Account Type
	public EditBankAccountPage SelectAccountType() throws InterruptedException{

		List<WebElement> ActType = driver.findElementsByXPath("//*[@class='radiomark']");
		if(ActType.get(ActType.size()-2).isEnabled())
		{
			clickByXpath("(//*[@class='radiomark'])[1]");
		}
		else
		{
			clickByXpath("(//*[@class='radiomark'])[2]");
		}
		Thread.sleep(2000);
		return new EditBankAccountPage(driver, test);

	}


	// Enter Account Number Number
	public EditBankAccountPage EnterAcctNum(String data) throws InterruptedException{
		enterById("accountNumber", data);
		Thread.sleep(2000);
		return this;

	}
	
	//Click Save Changes'
	public EditBankAccountPage ClickSaveChanges() throws InterruptedException{
		clickByXpath("//button[text()[contains(.,'Save changes')]]");
		Thread.sleep(10000);
		return this;

	}
	
	// Verify Edit Title
		public EditBankAccountPage VerifyEditTitle(String title) throws InterruptedException{
			verifyTextContainsById("takeoverTitle", title);
			return this;

		}

		// Verify Edit Description
		public EditBankAccountPage VerifyEditDescription(String Desc) throws InterruptedException{
			verifyTextContainsById("takeoverDescription", Desc);
			return this;

		}
		
		//Take a look
		public MyBankAccountsPage ClickTakeALook() throws InterruptedException{
			clickByXpath("//button[text()[contains(.,'Take a look')]]");
			return new MyBankAccountsPage(driver, test);

		}

}
