package pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.LeafTapsWrappers;

public class InvestmentSelectionPage extends LeafTapsWrappers  {

	// This is to confirm you are in Login Page
	public InvestmentSelectionPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;

		if(!verifyTitle("Oregon ABLE Savings Plan - Investment Selection")){
			reportStep("This is not Investment Selection Page", "FAIL");
		}
	}

	//Choose Investment option
	public InvestmentSelectionPage ClickInvestmentoption(String Option) throws InterruptedException{
		
		if(Option.equals("CONSERVATIVE"))
				{
			clickByXpath("(//div[@class='radio'])[2]");
				}
		else if(Option.equals("MODERATE"))
		{
			clickByXpath("(//div[@class='radio'])[3]");
		}
		else 
		{
			clickByXpath("(//div[@class='radio'])[1]");
		}
		Thread.sleep(2000);
		return this;

	}
	
	//Click "Go With this" option
		public ContributionSetUpPage ClickGoWithThis() throws InterruptedException{
			clickByXpath("//button[text()[contains(.,'Go with this')]]");
			Thread.sleep(3000);
			return new ContributionSetUpPage(driver, test);

		}
	
	
	}
