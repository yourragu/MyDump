package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.LeafTapsWrappers;

public class OregonAbleContactUsPage extends LeafTapsWrappers  {

	// This is to confirm you are in Login Page
	public OregonAbleContactUsPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;

		if(!verifyTitle("Oregon ABLE Savings Plan - Contact Customer Support")){
			reportStep("This is not Contact us page "+ " Page", "FAIL");
		}
	}


	//Click Ph option
	public OregonAbleContactUsPage ClickPhOption() throws InterruptedException{
		clickByXpath("(//*[@class='radio'])[2]");
		return this;

	}

	//Click Account
	public OregonAbleContactUsPage ClickAccount() throws InterruptedException{
		clickById("selectedSourceAccount");
		Thread.sleep(2000);
		return this;

	}


	//Select Account
	public OregonAbleContactUsPage SelectAccount() throws InterruptedException{
		clickByXpath("(//*[@role='presentation'])[2]");
		return this;

	}


	//Enter Message
	public OregonAbleContactUsPage EnterMessage(String Message) throws InterruptedException{
		enterById("message", Message);
		Thread.sleep(2000);
		return this;

	}


	//Click Send
	public OregonAbleContactUsPage ClickSend() throws InterruptedException{
		clickByXpath("//button[text()[contains(.,'Send')]]");
		Thread.sleep(15000);
		return this;
	}

	//Verify Confirmation Title
	public OregonAbleContactUsPage VerifyConfTitle(String text1) throws InterruptedException{
		verifyTextById("takeoverTitle", text1);
		Thread.sleep(2000);
		return this;
	}

	//Verify Confirmation Description
	public OregonAbleContactUsPage VerifyconfDescription(String text2) throws InterruptedException{
		verifyTextById("takeoverDescription", text2);
		Thread.sleep(2000);
		return this;
	}

	//Click Continue
	public OregonAbleContactUsPage ClickContinue() throws InterruptedException{
		clickByXpath("//button[text()[contains(.,'Continue')]] ");
		return this;
	}

	//Enter Name in customer support Page
	public OregonAbleContactUsPage EnterName(String name) throws InterruptedException{
		enterById("name", name);
		Thread.sleep(5000);
		return this;

	}

	//Click contact option
	public OregonAbleContactUsPage ChooseOption() throws InterruptedException{
		WebElement str = driver.findElementByXPath("(//*[@class='radio'])[1]");
		System.out.println(str);
		if(str.isSelected())
		{
			clickByXpath("(//*[@class='radio'])[1]");
		}
		else
		{
			clickByXpath("(//*[@class='radio'])[2]");

		}

		Thread.sleep(2000);
		return this;

	}


	//Enter PhNo
	public OregonAbleContactUsPage EnterPhoneNum(String PhNo) throws InterruptedException{
		enterById("phone", PhNo);
		Thread.sleep(3000);
		return this;

	}

}
