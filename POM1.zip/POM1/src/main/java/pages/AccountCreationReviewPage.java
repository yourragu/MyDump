package pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.LeafTapsWrappers;

public class AccountCreationReviewPage extends LeafTapsWrappers  {

	// This is to confirm you are in Login Page
	public AccountCreationReviewPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;

		if(!verifyTitle("Oregon ABLE Savings Plan - Account Creation Review")){
			reportStep("This is not Account Creation Review Page", "FAIL");
		}
	}

	

}
