package pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.LeafTapsWrappers;

public class ConditionPage extends LeafTapsWrappers  {

	// This is to confirm you are in Login Page
	public ConditionPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;

		if(!verifyTitle("Oregon ABLE Savings Plan - Edit Condition")){
			reportStep("This is not Condition Page", "FAIL");
		}
	}

	//Click penalty option radio button
	public ConditionPage ClickPenaltyradioOption2() throws InterruptedException{

		clickByXpath("(//*[@class='radio'])[2]");
		return this;
	}

	//Click penalty option radio button
	public ConditionPage ClickPenaltyradioOption3() throws InterruptedException{

		clickByXpath("(//*[@class='radio'])[3]");
		return this;
	}

	//Click diagnosis link
	public ConditionPage ClickDiagnosisOption() throws InterruptedException{
		clickByXpath("//*[@class='info-group']");
		return this;

	}

	//Choose diagnosis codes8
	public ConditionPage ClickDiagnosisCodes7() throws InterruptedException{
		clickByXpath("(//*[@class='radio'])[7]");
		Thread.sleep(2000);
		return this;
	}

	//Choose diagnosis codes10
	public ConditionPage ClickDiagnosisCodes8() throws InterruptedException{
		clickByXpath("(//*[@class='radio'])[8]");
		Thread.sleep(2000);
		return this;
	}


	//Click done
	public ConditionPage ClickDone() throws InterruptedException{
		clickByXpath("//button[@class='btn-submit']");
		Thread.sleep(2000);
		return this;

	}

	//Click disability 'NO'
	public ConditionPage ClickDisabilityTemporary() throws InterruptedException{
		clickByXpath("//*[@for='permanentDisabilityLabel_no']");
		Thread.sleep(1000);
		return this;

	}

	//Click disability 'YES'
	public ConditionPage ClickDisabilityPermanent() throws InterruptedException{
		clickByXpath("//*[@for='permanentDisabilityLabel_yes']");
		Thread.sleep(1000);
		return this;

	}

	//Click penalty option one
	public ConditionPage ClickPenaltyOneOption() throws InterruptedException{
		clickByXpath("(//*[@class='checkmark'])[1]");
		Thread.sleep(1000);
		return this;

	}

	//Click penalty option two
	public ConditionPage ClickPenaltyTwoOption() throws InterruptedException{
		clickByXpath("(//*[@class='checkmark'])[2]");
		Thread.sleep(1000);
		return this;

	}

	//Click penalty option three
	public ConditionPage ClickPenaltyThreeOption() throws InterruptedException{
		clickByXpath("(//*[@class='checkmark'])[3]");
		Thread.sleep(1000);
		return this;

	}

	//Click save changes
	public ConditionPage ClickConditionSaveChangesButton() throws InterruptedException{
		clickByXpath("//button[text()[contains(.,'Save Changes')]]");
		Thread.sleep(10000);
		return this;

	}

	//Verify Edit Condition Confirmation Screen
	public ConditionPage VerifyConditionConfirmation() throws InterruptedException{
		verifyTextById("takeoverTitle", "Got it");
		return this;

	}

	//Click Continue in Edit Condition confirmation screen
	public EditAccountInformationPage ClickContinue() throws InterruptedException{
		clickByXpath("//button[text()[contains(.,'Continue')]]");
		return new EditAccountInformationPage(driver,test);

	}




}
