package pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;

import com.google.common.collect.ImmutableBiMap.Builder;
import com.relevantcodes.extentreports.ExtentTest;

import wrappers.LeafTapsWrappers;

public class MyBankAccountsPage extends LeafTapsWrappers  {

	// This is to confirm you are in Login Page
	public MyBankAccountsPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;

		if(!verifyTitle("My Bank Accounts")){
			reportStep("This is not My Bank Account Page", "FAIL");
		}
	}




	//Click Add a new bank account link
	public AddNewBankAccountPage ClickBankLink() throws InterruptedException{
		clickByXpath("//button[text()[contains(.,'Add a new bank account')]]");
		Thread.sleep(2000);
		return new AddNewBankAccountPage(driver, test);

	}


	//Check through Accounts
	public MyBankAccountsPage CheckAllAccounts() throws InterruptedException{
		//Actions builder = new Actions(driver);
		List<WebElement> str= driver.findElementsByXPath("//*[@class='row-content']");
		str.get(str.size()-1).click();
		Thread.sleep(2000);
		return this;
	}

	//Click Edit
	public EditBankAccountPage ClickEdit() throws InterruptedException{
		clickByXpath("//button[text()[contains(.,'Edit')]]");
		Thread.sleep(2000);
		return new EditBankAccountPage(driver, test);
	}


	//Click Remove
	public MyBankAccountsPage ClickRemove() throws InterruptedException{
		clickByXpath("//button[text()[contains(.,'Remove')]]");
		Thread.sleep(2000);
		return this;
	}

	//Click Remove my bank account

	public MyBankAccountsPage ClickRemoveAccount() throws InterruptedException{
		clickByXpath("//button[text()[contains(.,'Remove this bank account')]]");
		Thread.sleep(2000);
		return this;
	}

	// Verify Remove Title
	public MyBankAccountsPage VerifyRemoveTitle(String title) throws InterruptedException{
		verifyTextContainsById("takeoverTitle", title);
		return this;

	}

	// Verify Remove Description
	public MyBankAccountsPage VerifyRemoveDescription(String Desc) throws InterruptedException{
		verifyTextContainsById("takeoverDescription", Desc);
		return this;

	}

	//Take a look
	public MyBankAccountsPage ClickTakeALook() throws InterruptedException{
		clickByXpath("//button[text()[contains(.,'Take a look')]]");
		Thread.sleep(2000);
		return this;

	}


}
