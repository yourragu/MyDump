package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.LeafTapsWrappers;

public class OregonAbleContactCustomerSupportPage extends LeafTapsWrappers  {

	// This is to confirm you are in Login Page
	public OregonAbleContactCustomerSupportPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;

		if(!verifyTitle("Contact Customer Support")){
			reportStep("This is not Contact Customer support Page"+ " Page", "FAIL");
		}
	}



	//Click Savings Frequently Asked Question
	public OregonAbleContactCustomerSupportPage SavingsFAQ() throws InterruptedException{
		clickByXpath("//*[@href='http://www.oregonablesavings.com/faqs']");
		switchToLastWindow();
		Thread.sleep(5000);
		driver.close();
		switchToLastWindow();
		return this;

	}

	//Click savings Contact Us
	public OregonAbleContactUsPage ClickSavingsContactUs() throws InterruptedException{
		clickByXpath("(//*[@href='/customer-support/oregon-able'])[1]");
		Thread.sleep(5000);
		return new OregonAbleContactUsPage(driver, test);

	}

	



}
