package pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.LeafTapsWrappers;

public class AddNewBankAccountPage extends LeafTapsWrappers  {

	// This is to confirm you are in Login Page
	public AddNewBankAccountPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;

		if(!verifyTitle("Add a New Bank Account")){
			reportStep("This is not Add a New Bank Account Page", "FAIL");
		}
	}



	// Choose Manual
	public AddNewBankAccountPage Choosebank() throws InterruptedException{
		clickByXpath("//*[@class='input-group option-list']");
		Thread.sleep(2000);
		clickByXpath("//span[text()[contains(.,'Other')]]");
		Thread.sleep(2000);
		return this;
	}

	// Click Done
	public AddNewBankAccountPage ClickDone() throws InterruptedException{
		clickByXpath("//button[text()[contains(.,' Done')]]");
		Thread.sleep(2000);
		return this;

	}


	// Click Name
	public AddNewBankAccountPage ClickName() throws InterruptedException{
		clickById("name");
		Thread.sleep(2000);
		return this;

	}

	// Select Name
	public AddNewBankAccountPage SelectName() throws InterruptedException{
		clickByXpath("(//*[@role='presentation'])[2]");
		Thread.sleep(2000);
		return this;

	}


	// Select Account Type
	public AddNewBankAccountPage SelectAccountType() throws InterruptedException{

		List<WebElement> ActType = driver.findElementsByXPath("//*[@class='radiomark']");
		System.out.println(ActType.size());

		if(ActType.get(ActType.size()-1).isEnabled())
		{
			clickByXpath("(//*[@class='radiomark'])[2]");
		}
		else
		{
			clickByXpath("(//*[@class='radiomark'])[1]");
		}
		Thread.sleep(2000);
		return this;

	}


	// Enter Routing Number
	public AddNewBankAccountPage EnterRoutingNum(String data) throws InterruptedException{
		enterById("routingNumber", data);
		Thread.sleep(2000);
		return this;

	}

	// Enter Account Number Number
	public AddNewBankAccountPage EnterAcctNum(String data) throws InterruptedException{
		enterById("accountNumber", data);
		Thread.sleep(2000);
		return this;

	}


	// Click Add Bank
	public AddNewBankAccountPage ClickAddBank() throws InterruptedException{
		clickByXpath("//button[text()[contains(.,'Add bank account')]]");
		Thread.sleep(15000);
		return this;

	}

	// Verify Title
	public AddNewBankAccountPage VerifyConfTitle(String title) throws InterruptedException{
		verifyTextContainsById("takeoverTitle", title);
		return this;

	}

	// Verify Description
	public AddNewBankAccountPage VerifyConfDescription(String Desc) throws InterruptedException{
		verifyTextContainsById("takeoverDescription", Desc);
		return this;

	}

	//Take a look
	public MyBankAccountsPage ClickTakeALook() throws InterruptedException{
		clickByXpath("//button[text()[contains(.,'Take a look')]]");
		return new MyBankAccountsPage(driver, test);

	}

	// Choose Plaid Bank
	public AddNewBankAccountPage ChoosePlaid() throws InterruptedException{
		clickByXpath("//*[@class='input-group option-list']");
		Thread.sleep(2000);
		clickByXpath("(//div[@class='radiomark'])[14]");
		Thread.sleep(2000);
		return this;
	}

	// Choose Plaid Account
	public AddNewBankAccountPage ChoosePlaidAccount() throws InterruptedException{
		clickByXpath("(//*[@class='info-group'])[2]");
		Thread.sleep(2000);
		return this;
	}

	// plaid UName
	public AddNewBankAccountPage PlaidUName(String name) throws InterruptedException{
		enterById("username", name);
		Thread.sleep(2000);
		return this;
	}

	// plaid Pwd
	public AddNewBankAccountPage PlaidPwd(String pwd) throws InterruptedException{
		enterById("password", pwd);
		Thread.sleep(2000);
		return this;
	}

	// Click Login
	public AddNewBankAccountPage ClickLogin() throws InterruptedException{
		clickByXpath("//button[text()[contains(.,'Login')]]");
		Thread.sleep(2000);
		return this;
	}

	// Connect Account
	public AddNewBankAccountPage ConnectAccount() throws InterruptedException{

		List<WebElement> Act = driver.findElementsByXPath("(//*[@class='radio'])");
		System.out.println(Act.size());

		if(Act.get(Act.size()-2).isEnabled())
		{
			clickByXpath("(//*[@class='radio'])[2]");
		}
		else
		{
			clickByXpath("(//*[@class='radiomark'])[3]");
		}
		Thread.sleep(2000);
		return this;

	}

	//Use account
	public AddNewBankAccountPage UseAccount() throws InterruptedException{
		clickByXpath("//button[text()[contains(.,' Use this account')]]");
		Thread.sleep(2000);
		return this;
	}
	
	//Verify Already Connected bank error
		public AddNewBankAccountPage AlreadyConnected(String error) throws InterruptedException{
			verifyTextByXpath("(//*[@class='validation server'])", error);
			Thread.sleep(2000);
			return this;
		}
	
	
	
	
}
