package pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.LeafTapsWrappers;

public class ConnectBankAccountPage extends LeafTapsWrappers  {

	// This is to confirm you are in Login Page
	public ConnectBankAccountPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;

		if(!verifyTitle("Oregon ABLE Savings Plan - Connect Bank Account")){
			reportStep("This is not Conect Bank Page", "FAIL");
		}
	}



	// Choose Bank (Manually select Bank Account)
	public ConnectBankAccountPage ChooseBank() throws InterruptedException{
		clickByXpath("(//div[@class='info-group'])");
		Thread.sleep(2000);
		return this;

	}

	// Choose Manual
	public ConnectBankAccountPage ChooseOther() throws InterruptedException{
		clickByXpath("//span[text()[contains(.,'Other')]]");
		Thread.sleep(2000);
		return this;

	}

	// Click Done
	public ConnectBankAccountPage ClickDone() throws InterruptedException{
		clickByXpath("//button[text()[contains(.,' Done')]]");
		Thread.sleep(2000);
		return this;

	}


	// Click Name
	public ConnectBankAccountPage ClickName() throws InterruptedException{
		clickById("name");
		Thread.sleep(2000);
		return this;

	}

	// Select Name
	public ConnectBankAccountPage SelectName() throws InterruptedException{
		clickByXpath("(//*[@role='presentation'])[4]");
		Thread.sleep(2000);
		return this;

	}

	// Select Account Type
	public ConnectBankAccountPage SelectAccountType(String str) throws InterruptedException{

		WebElement ActType = driver.findElementByXPath("(//*[@class='radiomark'])[1]");

		if(ActType.isSelected())
		{
			clickByXpath("(//*[@class='radiomark'])[2]");
		}
		else
		{
			clickByXpath("(//*[@class='radiomark'])[1]");
		}
		Thread.sleep(2000);
		return this;

	}

	// Enter Routing Number
	public ConnectBankAccountPage EnterRoutingNum(String data) throws InterruptedException{
		enterById("routingNumber", data);
		Thread.sleep(2000);
		return this;

	}

	// Enter Account Number Number
	public ConnectBankAccountPage EnterAcctNum(String data) throws InterruptedException{
		enterById("accountNumber", data);
		Thread.sleep(2000);
		return this;

	}


	// Time to Review
	public AccountCreationReviewPage TimetoReview() throws InterruptedException{
		clickByXpath("//button[text()[contains(.,' Time to review')]]");
		Thread.sleep(2000);
		return new AccountCreationReviewPage(driver, test);

	}
}
