package pages;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.LeafTapsWrappers;

public class GetStartedBeneALRPage extends LeafTapsWrappers  {
	public static String Balance;

	// This is to confirm you are in Login Page
	public GetStartedBeneALRPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;

		if(!verifyTitle("Get Started")){
			reportStep("This is not Get Started Page", "FAIL");
		}
	}

	//Enter New Email
	public GetStartedBeneALRPage EnterNewEmail(String text) throws InterruptedException{
		enterById("email", text);
		Thread.sleep(3000);
		return this;
	}

	//Select It's me option
	public GetStartedBeneALRPage SelectMe() throws InterruptedException{
		clickByXpath("//*[@for='ownerOption']");
		return this;
	}

	//Select SomeOne Else
	public GetStartedBeneALRPage SelectOther() throws InterruptedException{
		clickByXpath("//label[@for='alrLabel']/div");
		return this;
	}

	//Select Plan Document
	public GetStartedBeneALRPage SelectPlanDocument() throws InterruptedException{
		clickByXpath("(//*[@class='checkbox'])[1]");
		return this;
	}


	//Select Site Document
	public GetStartedBeneALRPage SelectSiteDocument() throws InterruptedException{
		clickByXpath("(//*[@class='checkbox'])[2]");
		return this;
	}

	// Click Statement option
	public GetStartedBeneALRPage ClickStatementOption() throws InterruptedException{
		clickByXpath("(//*[@for='emailAllForms'])");
		return this;
	}

	//Click Next
	public BeneficiaryInformationPage ClickNext() throws InterruptedException{
		clickByXpath("//button[text()[contains(.,'Next')]]");
		Thread.sleep(10000);
		return new BeneficiaryInformationPage(driver, test);
	}



	//Choose Oregon Able Plan

	public GetStartedBeneALRPage ChooseOregonAblePlan() throws InterruptedException{
		clickByXpath("//*[@for='planId-oregon-able']");
		return this;
	}
	//Choose Able for All Plan


	public GetStartedBeneALRPage ChooseAbleForOrAllPlan() throws InterruptedException{
		clickByXpath("//*[@for='planId-able-for-all']");
		return this;
	}
	
}

