package testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.AccountLoginPage;
import pages.GetStartedPage;
import pages.LoginPage;
import wrappers.LeafTapsWrappers;

public class TC022_Verify_Minor_Beneficiary_Validation extends LeafTapsWrappers{

	@BeforeClass
	public void setData() {
		testCaseName="22.Verify Minor Beneficiary Validation";
		testDescription="Minor Beneficiary";
		browserName="chrome";
		dataSheetName="TC023_ALRFlow";
		category="Sumday Able Program";
		authors="Ragunath";
	}


	@Test(dataProvider="fetchData")
	public void BeneficiaryRegistration(String Email,String text1, String text2, String text3, String text4, 
			String text5, String text6, String text7, String code, String Error, String Oldbirth, String MinAge, String BirthDate) throws InterruptedException{

		new AccountLoginPage(driver, test)
		.ClickGetStarted()
		.EnterNewEmail(Email)
		.SelectMe()
		.SelectPlanDocument()
		.SelectSiteDocument()
		.ClickNext()
		.EnterFirstName(text1)
		.EnterLastName(text2)
		.ClickGender()
		.SelectGender()
		.EnterBirthDate(text3)
		.EnterSSN(text4)
		.EnterPhoneNo(text5)
		.EnterLine1(text6)
		.EnterLine2(text7)
		.EnterZipCode(code)
		.ClickWithinNext()
		.VerifyDOBError(Error)
		.EnterReBirthDate(Oldbirth)
		.VerifyDOBMinAgeError(MinAge)
		.EnterDOB(BirthDate)
		.ClickNext()


		;






	}

}
