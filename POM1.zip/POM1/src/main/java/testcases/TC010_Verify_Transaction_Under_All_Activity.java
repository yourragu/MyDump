package testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import pages.LoginPage;
import wrappers.LeafTapsWrappers;

public class TC010_Verify_Transaction_Under_All_Activity extends LeafTapsWrappers{

	@BeforeClass
	public void setData() {
		testCaseName="10.Verify Transaction Under All Activity";
		testDescription="All Activity";
		browserName="chrome";
		dataSheetName="TC010_AllActivity";
		category="Sumday Able Program";
		authors="Ragunath";
	}

	@Test(dataProvider="fetchData")
	public void AllActivity(String Email, String Password) throws InterruptedException{

		new LoginPage(driver, test)
		.EnterEmailID(Email)
		.EnterPassWord(Password)
		.ClickLogin()
		.GetBalance()
		.Dashboardtile()
		.VerifyBalance()
		.ClickActivity()
		.VerifyActivityBalance()
		.CheckAllActivity();
			
		
	}

}
