package testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import pages.LoginPage;
import wrappers.LeafTapsWrappers;

public class TC016_CreateNewAccount extends LeafTapsWrappers{

	@BeforeClass
	public void setData() {
		testCaseName="Verify the Creation New Account ALR from the link)";
		testDescription="Create New Account ALR";
		browserName="chrome";
		dataSheetName="TC016_CreateNewAccount_ALR";
		category="Sumday Able Program";
		authors="Ragunath";
	}

	@Test(dataProvider="fetchData")
	public void CreateNewAccount(String Email, String Password, String text1, String text2, String text3, String text4, String NName, String CashInvestment) throws InterruptedException{

		new LoginPage(driver, test)
		.EnterEmailID(Email)
		.EnterPassWord(Password)
		.ClickLogin()
		//For SomeOne Else
		.ClickCreateNewAccount()
		.SelectOther()
		.ChooseOregonAblePlan()
		.SelectPlanDocument()
		.SelectSiteDocument()
		.ClickStatementOption()
		.ClickNext()
		.EnterFirstName(text1)
		.EnterLastName(text2)
		.EnterBirthDate(text3)
		.ClickGender()
		.SelectGenderShe()
		.EnterSSN(text4)
		.ClickRelationShip()
		.ClickPowerOfAttorney()
		.ClickPreSelectAddress()
		.SelectPreSelectAddress()
		
		
		
		;








	}

}
