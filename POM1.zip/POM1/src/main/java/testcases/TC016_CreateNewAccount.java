package testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import pages.LoginPage;
import wrappers.LeafTapsWrappers;


public class TC016_CreateNewAccount extends LeafTapsWrappers{
	
	@BeforeClass
	public void setData() {
		testCaseName="Verify the Creation New Account ALR from the link";
		testDescription="Create New Account ALR";
		browserName="chrome";
		dataSheetName="TC016_CreateNewAccount_ALR";
		category="Sumday Able Program";
		authors="Ragunath";
	}

	@Test(dataProvider="fetchData")
	public void CreateNewAccount(String Email, String Password, String text1, String text2, String text3, String text4, 
			String NName, String InvestAlloc, String option, String text7, String ActType, String RoutingNum, String AcctNum) throws InterruptedException{

		new LoginPage(driver, test)
		.EnterEmailID(Email)
		.EnterPassWord(Password)
		.ClickLogin()
		
		
		//For SomeOne Else
		.ClickCreateNewAccount()
		.SelectOther()
		.ChooseOregonAblePlan()
		.SelectPlanDocument()
		.SelectSiteDocument()
		.ClickStatementOption()
		.ClickNext()
		.EnterFirstName(text1)
		.EnterLastName(text2)
		.EnterBirthDate(text3)
		.ClickGender()
		.SelectGenderShe()
		.EnterSSN(text4)
		.ClickRelationShip()
		.ClickPowerOfAttorney()
		.ClickPreSelectAddress()
		.SelectPreSelectAddress()
		.ClickToNext()
		.ClickOption()
		.ClickDiagnosis()
		.SelectDiagnosis()
		.ClickDone()
		.ClickDisabilityNo()
		.ClickFirstPenalty()
		.ClickSecondPenalty()
		.ClickMoveOn()
		.ClickGetStarted()
		.EnterNickName(NName)
		.ClickSaveAndContinue()
		.EnterCashAllocation(InvestAlloc)
		.ClickNext()
		.ClickInvestmentoption(option)
		.ClickGoWithThis()
		.AddGoal()
		.AddMinimumAmount(text7)
		.MonthlyTransferSetUp()
		//.VerifyError(text8)
		//.ReEnterContribution(text8)
		.EditMonthlyTransfer()
		.SelectDate()
		.ClickDone()
		.ClickSaveAndContinue()
		.ChooseBank()
		.ChooseOther()
		.ClickDone()
		.ClickName()
		.SelectName()
		.SelectAccountType(ActType)
		.EnterRoutingNum(RoutingNum)
		.EnterAcctNum(AcctNum)
		.TimetoReview()
		

		;
		
		







	}

}
