package testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import pages.LoginPage;
import wrappers.LeafTapsWrappers;

public class TC020_Check_Bank_Account_Is_Created_Through_Manual_Flow extends LeafTapsWrappers{

	@BeforeClass
	public void setData() {
		testCaseName="20.Check bank account is created through Manual Flow";
		testDescription="Bank account is linked through link";
		browserName="chrome";
		dataSheetName="TC020_AddNewBankAccountManual";
		category="Sumday Able Program";
		authors="Ragunath";
	}

	@Test(dataProvider="fetchData")
	public void BankAccountLink(String Email, String Password, String Route, String Account, String title,
			String Desc, String Etitle, String EDesc,String Vtitle, String vDesc) throws InterruptedException{

		new LoginPage(driver, test)
		.EnterEmailID(Email)
		.EnterPassWord(Password)
		.ClickLogin()
		.ClickMyProfile()
		.ClickAccounts()
		.ClickBankLink()
		.Choosebank()
		.ClickDone()
		.ClickName()
		.SelectName()
		.SelectAccountType()
		.EnterRoutingNum(Route)
		.EnterAcctNum(Account)
		.ClickAddBank()
		.VerifyConfTitle(title)
		.VerifyConfDescription(Desc)
		.ClickTakeALook()
		.CheckAllAccounts()
		.ClickEdit()
		.SelectAccountType()
		.EnterAcctNum(Account)
		.ClickSaveChanges()
		.VerifyEditTitle(Etitle)
		.VerifyEditDescription(EDesc)
		.ClickTakeALook()
		.CheckAllAccounts()
		.ClickRemove()
		.ClickRemoveAccount()
		.VerifyRemoveTitle(Vtitle)
		.VerifyRemoveDescription(vDesc)
		.ClickTakeALook()

		;


	}

}
