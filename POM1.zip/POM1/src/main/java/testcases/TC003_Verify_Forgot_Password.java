package testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import pages.LoginPage;
import wrappers.LeafTapsWrappers;

public class TC003_Verify_Forgot_Password extends LeafTapsWrappers{

	@BeforeClass
	public void setData() {
		testCaseName="3.Verify Forgot Password";
		testDescription="Forgot Password Check";
		browserName="chrome";
		dataSheetName="TC003";
		category="Sumday Savings Plan";
		authors="Ragunath";
	}

	@Test(dataProvider="fetchData", threadPoolSize=2)
	public void ForgotPassword(String Email) throws InterruptedException {

		new LoginPage(driver, test)

		.ClickForgotPasswordLink()
		.VerifyPasswordText()
		.ClickSendHelp()
		.VerifyEmailValidationError()
		.EnterForgotPasword(Email)
		.ClickSendHelp()
		.VerifyForgotPasswordStaticText()
		.ClickTryAgain();
	}

}
