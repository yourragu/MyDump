package testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import pages.LoginPage;
import wrappers.LeafTapsWrappers;

public class TC019_CreatingBeneficiaryAccountWithoutCompletingSetUp extends LeafTapsWrappers{

	@BeforeClass
	public void setData() {
		testCaseName="Verify Beneficiary Account Without Completing the SetUp";
		testDescription="Creating Beneficiary Without Completing the SetUp";
		browserName="chrome";
		dataSheetName="Not Created Yet";
		category="Sumday Able Program";
		authors="Ragunath";
	}

	@Test(dataProvider="fetchData")
	public void HelpLoggedOut(String name,String PhNo, String Message, String text2, String text3) throws InterruptedException{

		new LoginPage(driver, test)
		.ClickGetHelp()
		.SavingsFAQ()
		.ClickSavingsContactUs()
		.EnterName(name)
		.ChooseOption()
		.EnterPhoneNum(PhNo)
		.EnterMessage(Message)
		.ClickSend()
		.VerifyConfTitle(text2)
		.VerifyconfDescription(text3)
		.ClickContinue()
		
		;
		
		
	}

}
