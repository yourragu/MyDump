package testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import pages.LoginPage;
import wrappers.LeafTapsWrappers;

public class TC017_Verify_Logged_In_Help_Screen extends LeafTapsWrappers{

	@BeforeClass
	public void setData() {
		testCaseName="17.Verify Logged In Help Screen";
		testDescription="Help Screen Logged In Version";
		browserName="chrome";
		dataSheetName="TC017_Help_LoggedIn";
		category="Sumday Able Program";
		authors="Ragunath";
	}

	@Test(dataProvider="fetchData")
	public void HelpLoggedIn(String Email, String Password, String Message, String text1, String text2) throws InterruptedException{

		new LoginPage(driver, test)
		.EnterEmailID(Email)
		.EnterPassWord(Password)
		.ClickLogin()
		.ClickLoggedInHelp()
		.SavingsFAQ()
		.ClickSavingsContactUs()
		.ClickPhOption()
		.ClickAccount()
		.SelectAccount()
		.EnterMessage(Message)
		.ClickSend()
		.VerifyConfTitle(text1)
		.VerifyconfDescription(text2)
		.ClickContinue()
		
		;
		
		
	}

}
