package testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import pages.LoginPage;
import wrappers.LeafTapsWrappers;

public class TC010_AllActivity extends LeafTapsWrappers{

	@BeforeClass
	public void setData() {
		testCaseName="Verify dashboard activity";
		testDescription="Dashboard Activity";
		browserName="chrome";
		dataSheetName="TC010_DashboardActivity";
		category="Sumday Able Program";
		authors="Ragunath";
	}

	@Test(dataProvider="fetchData")
	public void login(String Email, String Password) throws InterruptedException{

		new LoginPage(driver, test)
		.EnterEmailID(Email)
		.EnterPassWord(Password)
		.ClickLogin()
		.GetBalance()
		.Dashboardtile()
		.VerifyBalance()
		.ClickActivity()
		.VerifyActivityBalance()
		.CheckAllActivity();
		
		
	}

}
