package testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import pages.LoginPage;
import wrappers.LeafTapsWrappers;

public class TC021_Check_Bank_Account_Is_Created_Through_Plaid_Flow extends LeafTapsWrappers{

	@BeforeClass
	public void setData() {
		testCaseName="21.Check Bank Account is created through Plaid Flow";
		testDescription="Bank account is linked through Plaid";
		browserName="chrome";
		dataSheetName="TC021_AddNewBankAccountPlaid";
		category="Sumday Able Program";
		authors="Ragunath";
	}

	@Test(dataProvider="fetchData")
	public void BankAccountLink(String Email, String Password, String name, String pwd, String title, String Desc) throws InterruptedException{

		new LoginPage(driver, test)
		.EnterEmailID(Email)
		.EnterPassWord(Password)
		.ClickLogin()
		.ClickMyProfile()
		.ClickAccounts()
		.ClickBankLink()
		.ChoosePlaid()
		.ClickDone()
		.ClickName()
		.SelectName()
		.ChoosePlaidAccount()
		.PlaidUName(name)
		.PlaidPwd(pwd)
		.ClickLogin()
		.ConnectAccount()
		.UseAccount()
		.ClickAddBank()
		.VerifyConfTitle(title)
		.VerifyConfDescription(Desc)
		.ClickTakeALook()
		
	;


	}

}
